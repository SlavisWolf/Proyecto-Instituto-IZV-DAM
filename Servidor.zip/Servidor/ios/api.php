<?php
header('Content-Type: application/json');

require_once('../clases/AutoCarga.php');
require_once('../clases/vendor/autoload.php');

$json = json_decode(file_get_contents('php://input'));
$parametros = explode('/', $_GET['url']);



$api = new Api($_SERVER['REQUEST_METHOD'], $json, $parametros, $_GET);
$api->doTask();

echo $api->getResponse();














/*$por =array_splice($_GET, 0, 0);
foreach ($por as $indice => $get) {
        echo "$indice: $get </br>";
}*/

 /*
var_dump($json);
echo 'METODO: '.$_SERVER['REQUEST_METHOD'].'<hr>';
echo 'HOST: '.$_SERVER['HTTP_HOST'].'<hr>';
echo 'URI: '.$_SERVER['REQUEST_URI'].'<hr>';*/




/*foreach($parametros as $indice => $parametro) {
    echo '&nbsp;&nbsp;parametro: ' . $indice . ' => ' . $parametro . '<br>';
}*/
/*$api = new Api($_SERVER['REQUEST_METHOD'], $json, $parametros, $_GET);
$api->doTask();
echo $api->getResponse();*/

//require '../clases/AutoLoad.php';
//echo $_GET['url'];
/*$api = new ControladorApi();
$api->procesarPeticion();*/


/*$servidor = $_SERVER['HTTP_HOST'];
$ruta = $_SERVER['REQUEST_URI'];
echo '<br>servidor: ' . $servidor . '<br>';
echo 'ruta: ' . $ruta . '<br>';
echo 'trozo pasado por la regla .htaccess: ' . $_GET['url'] . '<br>';
$parametros = explode('/', $_GET['url']);
foreach($parametros as $indice => $parametro) {
    echo '&nbsp;&nbsp;parametro: ' . $indice . ' => ' . $parametro . '<br>';
}
$metodo = $_SERVER['REQUEST_METHOD'];
echo 'metodo: ' . $metodo . '<br>';
$json = file_get_contents('php://input');
echo 'parámetros json: ' . $json . '<br>';
$objeto = json_decode($json);
var_dump($objeto);//procedimiento -> print de variables complejas
echo '<pre>' . var_export($objeto, true) . '</pre>';
//valores importantes:
//1. $parametros: para crear la API rest
//2. metodo: DELETE (Delete), GET (Read), POST (Create), PUT (Update)
//3. objeto: sólo GET no pasa este parámetro, en los demás siempre puede estar*/


/*PRUEBAS JSON
    { "nombre":"kiko", "apellidos":"pepito perez", "telefono":"867-323-455","departamento":"informatica" } PROFE


*/