<?php

class ControladorProfesor extends Controlador{
    
    
   /* function __construct($objeto, $rest, $get){ // NO ES NECESARIO SI NO MODIFICAMOS NADA POR DEFECTO USA EL CONSTRUCTOR DLE PADRE
        parent::__construct($objeto,$rest,$get);
    }*/
    
    
    function delete(){ //borrar
        return $this->modelo->deleteProfesor($this->rest[1]);
    }
    
    function get(){ //obtener
        $id = $this->rest[1];
        if(!empty($id)) { // busca 1 elemento por ID
           return  $this->modelo->getProfesor($this->rest[1]);
        }
        elseif ($this->get) { //consulta, debemos especificar como parametros get en la url el campo y el valor que queremos.
            return $this->modelo->getProfesores($this->get);
        }
        else { // por defecto si solo especificamos la tabla, cogera todos los datos.
            return $this->modelo->getProfesores();
        }
    }
    
    function post(){ //insertar
        $profesor = new Profesor();
        $profesor->setNombre($this->objeto->nombre);
        $profesor->setApellidos($this->objeto->apellidos);
        $profesor->setTelefono($this->objeto->telefono);
        $profesor->setDepartamento($this->objeto->departamento);
        return $this->modelo->insert($profesor); //devuelve id
    }
    
    function put(){ //actualizar
        $profesor = $this->modelo->getProfesor($this->rest[1])[0]; // posicion 0 porque el modleo devuelve un array de 1 solo elemento
        $profesor->setNombre($this->objeto->nombre);
        $profesor->setApellidos($this->objeto->apellidos);
        $profesor->setTelefono($this->objeto->telefono);
        $profesor->setDepartamento($this->objeto->departamento);
        return $this->modelo->updateProfesor($profesor);
    }
}
    
