<?php

class ControladorActividad extends Controlador{
   /* function __construct($objeto, $rest, $get){ // NO ES NECESARIO SI NO MODIFICAMOS NADA POR DEFECTO USA EL CONSTRUCTOR DLE PADRE
        parent::__construct($objeto,$rest,$get);
    }*/
    function delete(){ //borrar
        return $this->modelo->deleteActividad($this->rest[1]);
    }
    
    function get(){ //obtener
        $id = $this->rest[1];
        if(!empty($id)) { // busca 1 elemento por ID
           return  $this->modelo->getActividad($this->rest[1]) ;
        }
        elseif ($this->get) { //consulta, debemos especificar como parametros get en la url el campo y el valor que queremos.
            return $this->modelo->getActividades($this->get);
        }
        else { // por defecto si solo especificamos la tabla, cogera todos los datos.
            return $this->modelo->getActividades();
        }
    }
    
    function post(){ //insertar
        $actividad = new Actividad();
        $actividad->setTitulo($this->objeto->titulo);
        $actividad->setDescripcion($this->objeto->descripcion);
        $actividad->setResumen($this->formarResumen($actividad->getDescripcion()));
        $actividad->setFecha(date_create($this->objeto->fecha));
        $actividad->setHora_salida(date_create($this->objeto->hora_salida));
        $actividad->setHora_vuelta(date_create($this->objeto->hora_vuelta));
        $actividad->setFoto($this->objeto->foto);
        $actividad->setProfesor($this->modelo->getProfesor($this->objeto->profesor_id)[0]);
        $actividad->setGrupo($this->modelo->getGrupo($this->objeto->grupo_id)[0]);
        return $this->modelo->insert($actividad); //devuelve id
    }
    
    function put(){ //actualizar
        $actividad = $this->modelo->getActividad($this->rest[1])[0];
        $actividad->setTitulo($this->objeto->titulo);
        $actividad->setDescripcion($this->objeto->descripcion);
        $actividad->setResumen($this->formarResumen($actividad->getDescripcion()));
        $actividad->setFecha(date_create($this->objeto->fecha));
        $actividad->setHora_salida(date_create($this->objeto->hora_salida));
        $actividad->setHora_vuelta(date_create($this->objeto->hora_vuelta));
        $actividad->setFoto($this->objeto->foto);
        $actividad->setProfesor($this->modelo->getProfesor($this->objeto->profesor_id)[0]);
        $actividad->setGrupo($this->modelo->getGrupo($this->objeto->grupo_id)[0]);
        return $this->modelo->updateActividad($actividad);
    }
    
    
    private function formarResumen($descripcion) {
        return strlen($descripcion) > 70  ? substr($descripcion,0,70)."..." : substr($descripcion,0,70);
    }
    
    //{ "titulo":"Viaje a sierra nevada", "descripcion":"Pasear por sierra nevada, hacer esqui etc...", "resumen":"campo","fecha":"2020-05-15","hora_salida":"09:00","hora_vuelta":"15:30","foto":"troll.jpg","profesor_id":1,"grupo_id":1 }
}
    
