<?php

class ControladorGrupo extends Controlador{
    
    
   /* function __construct($objeto, $rest, $get){ // NO ES NECESARIO SI NO MODIFICAMOS NADA POR DEFECTO USA EL CONSTRUCTOR DLE PADRE
        parent::__construct($objeto,$rest,$get);
    }*/
    
    
    function delete(){ //borrar
        return $this->modelo->deleteGrupo($this->rest[1]);
    }
    
    function get(){ //obtener
        $id = $this->rest[1];
        if(!empty($id)) { // busca 1 elemento por ID
           return  $this->modelo->getGrupo($this->rest[1]);
        }
        elseif ($this->get) { //consulta, debemos especificar como parametros get en la url el campo y el valor que queremos.
            return $this->modelo->getGrupos($this->get);
        }
        else { // por defecto si solo especificamos la tabla, cogera todos los datos.
            return $this->modelo->getGrupos();
        }
    }
    
    function post(){ //insertar
        $grupo = new Grupo();
        $grupo->setAula($this->objeto->aula);
        $grupo->setCurso($this->objeto->curso);
        return $this->modelo->insert($grupo); //devuelve id
    }
    
    function put(){ //actualizar
        $grupo = $this->modelo->getGrupo($this->rest[1])[0];
        $grupo->setAula($this->objeto->aula);
        $grupo->setCurso($this->objeto->curso);
        return $this->modelo->updateGrupo($grupo);
    }
}
    
