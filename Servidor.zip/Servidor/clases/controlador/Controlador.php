<?php

abstract  class Controlador{ //PADRE DE LOS DEMAS CONTROLADORES
    
    protected $objeto, $rest, $get;
    protected $modelo;
    
    function __construct($objeto, $rest, $get){
        $this->objeto = $objeto; //JSON
        $this->rest = $rest; //URL
        $this->get = $get; //GET
        $this->modelo = new Modelo();
    }
    
    //getter

    function getUrlParameters(){
        return $this->get;
    }

    function getObject(){
        return $this->objeto;
    }

    function getRestParameters(){
        return $this->rest;
    }

    //métodos REST

    abstract  function delete();

    abstract  function get();
    
    abstract  function post();
    
    abstract  function put();
    
}