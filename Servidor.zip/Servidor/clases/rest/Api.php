<?php

class Api {
    
    private $metodo, $json, $pRest, $pGet;
    private $respuesta;
    
    function __construct($metodo, $json, $parametrosRest, $parametrosGet) {
        $this->metodo = $metodo;
        $this->json = $json;
        $this->pRest = $parametrosRest;
        $this->pGet = array();
        foreach ($parametrosGet as $indice => $valor) { //hacemos una copia del array $get sin el parametro url que lo guardamos en $parametros
             if ($indice!='url') 
                $this->pGet[$indice]=$valor;
        }
    }
    
    function doTask(){
        
        $tabla = $this->pRest[0];
        $clase = 'Controlador' . ucfirst($tabla);
        if(class_exists($clase)){
            $objeto = new $clase($this->json, $this->pRest, $this->pGet);
            $metodo = $this->metodo;
            if(method_exists($objeto, $metodo)){
                $this->respuesta = $objeto->$metodo();
            }
        }
        /*if(isset($this->pRest[0])){
            $this->respuesta = $this->pRest[0];
            if($this->respuesta === 'insert'){
                $p = new Persona();
                $p->setNombre($this->pRest[1]);
                $this->gestor->persist($p);
                $this->gestor->flush();
                $array = array('r' => $p->getId());
                $this->respuesta = json_encode($array);
            } else if($this->respuesta === 'ver'){
                $p = new Persona();
                $p->setId(1)->setNombre('Ana');
                $q = new Persona();
                $q->setId(2)->setNombre('Paco');
                $array = array();
                $array[] = $p->toArray();
                $array[] = $q->toArray();
                $this->respuesta = json_encode($array);
            }
            
        } else {
            $this->respuesta = 'sin peticion REST';
        }*/
    }
    
    function getResponse(){ // tiene que analizar el tipo de respuesta para dar una respuesta u otra
        $res = $this->respuesta;
        if (is_bool($res))  {
            return $res ? 'Operación realizada correctamente.' : 'La operación no pudo realizarse, compruebe que los datos son correctos.' ;
        }
        
        elseif (is_array($res)) {
            foreach ($res as $i => $objeto) {
                    $res[$i] = $objeto->toArray();
            }
            return json_encode($res);
        }
       /* elseif (is_object($res)) { obsoleto, ahora el modleo siempre devuelve un array
            return json_encode($res->toArray());
        }*/
        elseif (is_numeric($res))  {
            return $res; 
        }
        else {
            return "No hay datos o la operación que has intentado realizar no es posible.";
        }
    }
}