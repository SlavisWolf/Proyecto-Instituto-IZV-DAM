<?php

use Doctrine\Common\Collections\ArrayCollection;
/**
     * @Entity @Table(name="grupo")
     **/
class Grupo
{
    /**
         * @Id
         * @Column(type="integer") @GeneratedValue
         */
    protected $id;
    /**
         * @Column(type="string", length=25, unique=false, nullable=false)
    */
    protected $aula;
    
    /**
         * @Column(type="string", length=25, unique=false, nullable=false)
    */
    protected $curso;
    
     /**
     * One group have several Activities.
     * @OneToMany(targetEntity="Actividad",mappedBy="grupo")
     */
    protected $actividades=null;
    
    public function __construct(){
        $this->actividades = new ArrayCollection();
    }
    

    public function getId()
    {
        return $this->id;
    }

    public function getAula()
    {
        return $this->aula;
    }

    public function setAula($aula)
    {
        $this->aula = $aula;
    }
    
    public function getCurso()
    {
        return $this->curso;
    }

    public function setCurso($curso)
    {
        $this->curso = $curso;
    }
    
    public function getActividades()
    {
        return $this->actividades;
    }
    
    public function addActividad($actividad) {
        $this->actividades[]=$actividad;
    }
    
    public function actualizarGrupo(Grupo $objeto) {
        $this->actualizarCampos($objeto->getAula(),
                                    $objeto->getCurso(),
                                    $objeto->getActividades());
    }
    
    private function actualizarCampos($aula,$curso,$actividades) {
        if ($aula!==null) {
            $this->aula=$aula;
        }
        
        if ($curso!==null) {
            $this->curso=$curso;
        }
        
        if ($actividades!==null) {
            $this->actividades=$actividades;
        }
    }
    
    public function toArray() {
        return array (
                        'id'            => $this->id,
                        'aula'        => $this->aula,
                        'curso'     => $this->curso
                    );
    }
}