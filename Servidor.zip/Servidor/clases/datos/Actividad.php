<?php
/**
     * @Entity 
     * @Table(name="actividad")
     * 
     **/
class Actividad
{
    /**
         * @Id
         * @Column(type="integer") @GeneratedValue
         */
    protected $id;
    /**
         * @Column(type="string", length=80, unique=false, nullable=false)
    */
    protected $titulo;
    
    /**
         * @Column(type="string", length=600, unique=false, nullable=false)
    */
    protected $descripcion;
    
    /**
         * @Column(type="string", length=150, unique=false, nullable=true)
    */
    protected $resumen;
    
    /**
         * @Column(type="date", unique=false, nullable=false)
    */
    protected $fecha;
    
    /**
         * @Column(type="time", unique=false, nullable=false)
    */
    protected $hora_salida;
    
    /**
         * @Column(type="time", unique=false, nullable=false)
    */
    protected $hora_vuelta;
    
    /**
         * @Column(type="string", length=400, unique=false, nullable=true)
    */
    protected $foto;
    
    /**
     * Many Activities have One Teacher.
     * @ManyToOne(targetEntity="Profesor",inversedBy="actividades")
     * @JoinColumn(name="profesor_id", referencedColumnName="id",nullable=false)
     */
    protected $profesor;
    
    /**
     * Many Activities have One Group.
     * @ManyToOne(targetEntity="Grupo",inversedBy="actividades")
     * @JoinColumn(name="grupo_id", referencedColumnName="id",nullable=false)
     */
    protected $grupo;
    

    public function getId()
    {
        return $this->id;
    }
    
     public function setId($id)
    {
        $this->id = $id;
    }

    public function getTitulo()
    {
        return $this->titulo;
    }

    public function setTitulo($titulo)
    {
        $this->titulo = $titulo;
    }
    
    public function getDescripcion()
    {
        return $this->descripcion;
    }

    public function setDescripcion($descripcion)
    {
        $this->descripcion = $descripcion;
    }
    
     public function getResumen()
    {
        return $this->resument;
    }

    public function setResumen($resumen)
    {
        $this->resumen = $resumen;
    }
    
     public function getFecha()
    {
        return $this->fecha;
    }

    public function setFecha($fecha)
    {
        $this->fecha = $fecha;
    }
    
     public function getHora_salida()
    {
        return $this->hora_salida;
    }

    public function setHora_salida($hora_salida)
    {
        $this->hora_salida = $hora_salida;
    }
    
    public function getHora_vuelta()
    {
        return $this->hora_vuelta;
    }

    public function setHora_vuelta($hora_vuelta)
    {
        $this->hora_vuelta = $hora_vuelta;
    }
    
    public function getFoto()
    {
        return $this->foto;
    }

    public function setFoto($foto)
    {
        $this->foto = $foto;
    }
    
    public function getProfesor()
    {
        return $this->profesor;
    }

    public function setProfesor($profesor)
    {
        $this->profesor = $profesor;
    }
    
    public function getGrupo()
    {
        return $this->grupo;
    }

    public function setGrupo($grupo)
    {
        $this->grupo = $grupo;
    }
    
    public function actualizarActividad(Actividad $objeto) {
        $this->actualizarCampos($objeto->getTitulo(),
                                    $objeto->getDescripcion(),
                                    $objeto->getResumen(),
                                    $objeto->getFecha(),
                                    $objeto->getHora_salida(),
                                    $objeto->getHora_vuelta(),
                                    $objeto->getFoto(),
                                    $objeto->getProfesor(),
                                    $objeto->getGrupo());
    }
    
    private function actualizarCampos($titulo,$descripcion,$resumen,$fecha,$hora_salida,$hora_vuelta,$foto,$profesor,$grupo) {
        if ($titulo!==null) {
            $this->titulo=$titulo;
        }
        
        if ($descripcion!==null) {
            $this->descripcion=$descripcion;
        }
        
        if ($resumen!==null) {
            $this->resumen=$resumen;
        }
        
        if ($fecha!==null) {
            $this->fecha=$fecha;
        }
        
        if ($hora_salida!==null) {
            $this->hora_salida=$hora_salida;
        }
        
        if ($hora_vuelta!==null) {
            $this->hora_vuelta=$hora_vuelta;
        }
        
        if ($foto!==null) {
            $this->foto=$foto;
        }
        
        if ($profesor!==null) {
            $this->profesor=$profesor;
        }
        
        if ($grupo!==null) {
            $this->grupo=$grupo;
        }
    }
    
    public function toArray() {
        return array (
                        'id'                => $this->id,
                        'titulo'            => $this->titulo,
                        'descripcion'       => $this->descripcion,
                        'resumen'           => $this->resumen,
                        'fecha'             => $this->fecha->format('Y-m-d'),
                        'hora_salida'       => $this->hora_salida->format('H:i:s'),
                        'hora_vuelta'       => $this->hora_vuelta->format('H:i:s'),
                        'foto'              => $this->foto,
                        'profesor_id'       => $this->profesor->getId(),
                        'grupo_id'          => $this->grupo->getId()
                    );
    }
}