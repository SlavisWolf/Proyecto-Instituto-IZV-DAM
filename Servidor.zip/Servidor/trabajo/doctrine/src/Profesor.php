<?php

use Doctrine\Common\Collections\ArrayCollection;
/**
     * @Entity @Table(name="profesor")
     **/
class Profesor
{
    /**
         * @Id
         * @Column(type="integer") @GeneratedValue
         */
    protected $id;
    /**
         * @Column(type="string", length=50, unique=false, nullable=false)
    */
    protected $nombre;
    /**
         * @Column(type="string", length=50, unique=false, nullable=false)
    */
    protected $apellidos;
    
    /**
         * @Column(type="string", length=12, unique=false, nullable=false)
    */
    
    protected $telefono;
    
    /**
         * @Column(type="string", length=50, unique=false, nullable=false)
    */
    protected $departamento;
    
    /**
     * One Profesor have several Activities.
     * @OneToMany(targetEntity="Actividad",mappedBy="profesor")
     */
    protected $actividades=null;
    
    
    public function __construct(){
        $this->actividades = new ArrayCollection();
    }

    public function getId()
    {
        return $this->id;
    }

    public function getNombre()
    {
        return $this->nombre;
    }

    public function setNombre($nombre)
    {
        $this->nombre = $nombre;
    }
    
     public function getApellidos()
    {
        return $this->apellidos;
    }

    public function setApellidos($apellidos)
    {
        $this->apellidos = $apellidos;
    }
    
      public function getTelefono()
    {
        return $this->telefono;
    }

    public function setTelefono($telefono)
    {
        $this->telefono = $telefono;
    }
    
     public function getDepartamento()
    {
        return $this->departamento;
    }

    public function setDepartamento($departamento)
    {
        $this->departamento = $departamento;
    }
    
    
    public function getActividades(){
        return $this->actividades;
    }
    
    public function addActividad($actividad) {
        $this->actividades[]=$actividad;
    }
    
    public function actualizarProfesor(Profesor $objeto) {
        $this->actualizarCampos($objeto->getNombre(),
                                    $objeto->getApellidos(),
                                    $objeto->getTelefono(),
                                    $objeto->getDepartamento(),
                                    $objeto->getActividades());
    }
    
    private function actualizarCampos($nombre,$apellidos,$telefono,$departamento,$actividades) {
        if ($nombre!==null) {
            $this->nombre=$nombre;
        }
        
        if ($apellidos!==null) {
            $this->apellidos=$apellidos;
        }
        
        if ($telefono!==null) {
            $this->telefono=$telefono;
        }
        
        if ($departamento!==null) {
            $this->departamento=$departamento;
        }
        
        if ($actividades!==null) {
            $this->actividades=$actividades;
        }
    }
    
    public function toArray() {
        return array (
                        'id'            => $this->id,
                        'nombre'        => $this->nombre,
                        'apellidos'     => $this->apellidos,
                        'telefono'      => $this->telefono,
                        'departamento'  => $this->departamento
                    );
    }
}